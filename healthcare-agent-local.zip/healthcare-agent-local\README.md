# Healthcare Agent 2

A hackathon-friendly healthcare assistant built around the flow you described:

1. Patient input
2. Memory load
3. Intent classification and care planning
4. Specialist routing
5. Patient-friendly response synthesis
6. Safety guardrails
7. Patient reply
8. Memory update

The local version runs with rule-based fallbacks, structured care-plan metadata, and an expanded medical knowledge base, so you can demo it without API keys. Optional hooks are included for LangGraph, ChromaDB, calendar APIs, OpenAI models, and Twilio.

The agent now tracks route scores, primary and secondary intents, urgency, extracted clinical slots, medication risk factors, vital-style readings, negated red-flag phrases, missing information, quality gates, planned agent actions, model-efficiency metadata, an 8-step workflow trace, a source-quality governance card, and patient-provided profile memory across turns.

See `DEEP_RESEARCH_AGENTIC_MODEL.md` for the research-backed model improvement brief.

## Architecture

```mermaid
flowchart TD
    A["Patient Input"] --> B["Load Memory / LangGraph State"]
    B --> C["Intent Classifier Agent"]

    C --> C2["Care Plan<br/>Urgency, slots, missing info, quality gates, actions"]
    C2 -->|General health question| D["RAG Agent"]
    C2 -->|Medication related| E["Pharmacy Agent"]
    C2 -->|Appointment needed| F["Scheduling Agent"]
    C2 -->|Emergency signal| G["Alert Agent"]

    D --> H["Response Synthesizer"]
    E --> H
    F --> H
    G --> H

    H --> I["Safety & Guardrails"]
    I --> J["Patient Reply"]
    J --> K["Update Memory"]
    K -.-> A
```

See `ARCHITECTURE.md` for the full implementation mapping, specialist-agent responsibilities, safety model, and production upgrade path.

## Quick Start

For the easiest local demo on Windows:

```powershell
.\launch_app.cmd
```

This starts a local server, finds an available port, and opens the browser.
When the app is opened from this local server, conversations, profile memory, and the selected patient ID are saved in `.localhost_store/` on this machine, with browser storage as a fallback.

If you want the older hidden-server launcher:

```powershell
.\start_local_server.cmd
```

The browser opens automatically. If port `8501` is busy, the launcher uses the next available port.

See `APP_USAGE_ARCHITECTURE.md` for the full web/local/install usage architecture.

## Installable App

The web app is PWA-ready for iOS, Android, Windows, and macOS:

- Open the deployed site and use the front page **Install App** button.
- Use **Login on Web** for the browser-hosted demo.
- Use **Use Local Mode** for device-only browser memory.
- Use **Download Local App** to get a zip package that can run from `localhost`.

See `LOCAL_INSTALL.md` for platform-specific install notes.

To rebuild the downloadable package after changes:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build_package.ps1
```

The package includes the browser app, the Python agent model, sample data, tests, Streamlit demo, and launch scripts.

For the Streamlit version:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run streamlit_app.py
```

For a quick terminal check:

```powershell
python -m healthcare_agent.cli "What are ibuprofen side effects?"
```

Then try:

- "I have a headache"
- "What are ibuprofen side effects?"
- "When is my next appointment?"
- "I have chest pain and cannot breathe"

## Standalone Browser App

The no-install app is split into:

- `standalone_app.html` for layout
- `app.css` for the care workspace design
- `app.js` for local routing, memory, safety, retrieval, and UI state
- `data/medical_faqs.json` for 20 medical knowledge topics
- `data/drugs.json` for 12 medication entries

## Web Version

The browser app is in `web/`. The local launcher serves this folder on `localhost`, and the front page download uses:

- `web/index.html`
- `web/app.css`
- `web/app.js`
- `web/manifest.webmanifest`
- `web/service-worker.js`
- `web/data/`
- `web/icons/`
- `web/downloads/healthcare-agent-local.zip`

The hosted app stores demo patient data in the browser only. Local machine storage through `.localhost_store/` is only used when running through `launch_app.cmd` or `serve_local.ps1`.

## Optional Integrations

Create a `.env` file from `.env.example` if you want live integrations.

- `ENABLE_REAL_ALERTS=true` enables Twilio alerts when Twilio credentials are present.
- ChromaDB is used as the local FAQ vector store when installed. The project uses simple offline hash embeddings so the demo does not need a network-hosted embedding model.
- OpenAI support is optional for the response synthesizer when `OPENAI_API_KEY` is set.
- Calendar APIs can replace the local appointment JSON store.

## Safety Note

This project is for demonstration and education. It does not diagnose medical conditions or replace a licensed clinician. Emergency language is routed to the alert path and tells the patient to contact local emergency services immediately.
